package com.example.demo.controller;

public class AddResponse {
	
	int Id;
	String msg;
	
	public AddResponse()
	{}
	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
